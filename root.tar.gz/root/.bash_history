vim /etc/ssh/sshd_config
cd  .ssh
ls authorized_keys
touch authorized_keys
ls authorized_keys
vim authorized_keys
vim authorized_keys
cd
ip a
systemctl restart sshd.service
scp c:\temp\clave_privada.txt root@192.168.0.250:/root/
cd .ssh
ls authorized_keys
vim authorized_keys
cd
mkdir root/clave_privada
mkdir /root/clave_privada
ls
cd clave_privada
touch id_rsa
ls
cd
ls
cd .ssh
ls
cd
cp /.ssh/authorized_keys /root/clave_privada/authorized_keys
cp .ssh/authorized_keys /root/clave_privada/authorized_keys
cd .ssh
ls
cd
ls
cd clave_privada
ls
vim authorized_keys
clear
rm id_rsa
mv authorized_keys id_rsa
ls
vim id_rsa
cd
cd .ssh
ls
rm authorized_keys
ls
cd
vim /etc/ssh/sshd_config
clear
chmod 600 /root/.ssh/authorized_keys
cd .ssh
ls
touch authorized_keys
ls
cd
chmod 600 /root/clave_privada/id_rsa
vim /etc/ssh/sshd_config
ip a
systemctl restart ssh
ip a
cd .ssh
ls
cd
mount /root/.ssh/authorized_keys
ls /etc/fstab
ls -l /etc/fstab
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
ls -l
cd temp
cd tmp
cd /tmp/
cd
cd /tmp/
ls
ls -la
cd
cd .ssh
ls
vim autorized_keys
vim autorized_keys
cd
ls -l
cd .ssh
vim autorized_keys
cd
systemctl restart ssh
cd .ssh
ls -l
vim autorized_keys
vim authorized_keys
mv autorized_keys authorized_keys
vim authorized_keys
ls -l
cd
systemctl restart ssh
cd .ssh
ls -l
vim authorized_keys
ls -la
chmod 600 /root/.ssh/authorized_keys
ls -la
systemctl restart ssh
cd
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
cd .ssh
vim authorized_keys
systemctl restart ssh
cd
chmod 700 /root/.ssh
ls -la /root/.ssh
systemctl restart ssh
chown root:root -R /root/.ssh
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
cd .ssh
ls -la
cd
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
vim /root/.ssh/known_hosts
vim /root/.ssh/known_hosts
vim /root/.ssh/known_hosts
clear
ssh host
ip a
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
vim /root/.ssh/known_hosts
clear
vim /root/.ssh/known_hosts
vim authorized_keys
ls -l
cd .ssh
ls -l
vim authorized_keys
cd
ssh -i /root/clave_privada/is_rsa root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
ip a
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chown root:root -R /root/.ssh
chmod 600 /root/clave_privada/id_rsa
vim /etc/network/interfaces
ssh-copy-id root@192.168.0.250
ssh-keygen
cd .ssh
ls -la
vim id_rsa
ls -la
vim authorized_keys
ls -la
vim id_rsa.pub
systemctl restart ssh
ls -la
cp authorized_keys id_rsa.pub
vim id_rsa.pub
ls -la
vim authorized_keys
ls -la
cd
ls -la
cp /root/clave_privada /root/.ssh/id_rsa
vim clave_privada
vim /root/clave_privada/id_rsa
cd .ssh
ls -la
vim id_rsa
cp /root/clave_privada/id_rsa /root/.ssh/id_rsa
vim id_rsa
cd
ls -la
cd clave_privada
ls -la
cd
rmdir clave_privada
vim /etc/ssh/sshd_config
clear
ls -la
cd clave_privada
ls -la
cd
cd .ssh
ls -la
cat known_hosts
cd authorizaed_keys
cd authorized_keys
cat authorized_keys
cat id_rsa.pub
chmod 600 /root/.ssh/id_rsa.pub
ls -la
cd
ssh-copy-id root@192.168.0.250
cd .ssh
ls -la
rm id_rsa
ls -la
cd
ls -la
cd clave_privada
ls -la
cd
ssh-copy-id root@192.168.0.250
ssh-copy-id -i root/.ssh/id_ed25519 root@192.168.0.250
cd .ssh
ls -la
ssh-copy-id -i root/.ssh/known_hosts/id_ed25519 root@192.168.0.250
cd
ls -la
poweroff
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
vim id_rsa
cd clave_privada
ls -la
cat id_rsa
vim id_rsa
cat id_rsa
cd
cd .ssh
ls -la
cat id_rsa.pub
cat authorized_keys
rm id_rsa.pub
ls -la
cat known_hosts
cd
ls -la
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
cd clave_privada
ls -la
cd
ssh-keygen -y -f /root/clave_privada/id_rsa
ssh-keygen -t rsa -b 4096 -f /root/clave_privada/id_rsa
ls -la
cd clave_privada
ls -la
cat id_rsa
cd
cd clave_privada
ls -la
cd
find id_rsa.pub
cd .ssh
ls -la
cat authorized_keys
cd
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
ls -la /root/
ls -la /root/clave_privada
ls -la /root/.ssh/
ls -la /root/.ssh/authorized_keys
ssh-keygen -y -f /root/clave_privada/id_rsa
cat /root/.ssh/authorized_keys
vim /root/clave_privada/id_rsa
poweroff
exit
exit
exit
exit
exit
exit
exit
exit
exit
exit
exit
exit
exit
ssh-keygen -y -f /root/clave_privada/id_rsa
vim /etc/ssh/sshd_config
system restart ssh
systemctl restart ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh-keygen -y -f /root/clave_privada/id_rsa
cd clave_privada
ls -la
cat id_rsa
cd
cd .ssh
ls -la
cat authorized_keys
cd
ls -la
cd
chmod 600 /root/clave_privada/id_rsa
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
ssh-keygen -y -f /root/clave_privada/id_rsa
cat /root/.ssh/authorized_keys
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
ip a
ssh -i /root/clave_privada/id_rsa root@192.168.0.255
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
ssh -i /root/.ssh/authorized_keys root@192.168.0.250
ssh -i /root/clave_privada/id_rsa root@192.168.0.250
clear
vim /etc/network/interfaces
clear
apt install apache2 php libapache2-mod-php
php -v
systemctl status apache2
ls -la
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ls -la
ls -la
ssh-copy-id root 192.168.0.250
/usr/bin/ssh-copy-id root 192.168.0.250
/usr/bin/ssh-copy-id -h
/usr/bin/ssh-copy-id
ssh-copy-id root@192.168.0.250
cd bin
cd .ssh
ls -la
ssh-copy-id root@192.168.0.250
cd
cd .ssh
ls -la
touch id_rsa.pub
cp authorized_keys id_rsa.pub
ls -la
cat id_rsa.pub
cd

cd .ssh
touch id_rsa
ls -la
cp /root/clave_privada/id_rsa id_rsa
cat id_rsa
cd
cd clave_privada
cat id_rsa
cd

vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh root@192.168.0.250
ssh-keygen
cd .ssh
ls -la
cp /root/clave_privada/id_rsa id_rsa
ls -la
cp clave_publica.pub id_rsa.pub
rm clave_publica.pub
cd
ssh root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh root@192.168.0.250
ssh-copy-id root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh-copy-id root@192.168.0.250
ssh root@192.168.0.250
chmod 600 /root/.ssh/id_rsa
chmod 600 /root/.ssh/id_rsa.pub
ssh root@192.168.0.250
ssh root@192.168.0.250
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl restart ssh.service
ssh root@192.168.0.250
ssh root@192.168.0.250
ls -la
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
http://192.168.0.250/index.php
cd /var/www/html/
ls -la
http://192.168.0.250/logo.png
ls -la
cd
ls -la
cd /var/www/html/
ls -la
rm index.php
rmlogo.png
rm logo.png
ls -la
cd
ls -la
cp /root/logo.png /var/www/html/
cp /root/index.php /var/www/html/
cd /var/www/html/
ls -la
cat index.php
cd
clear
vim /etc/apache2/mods-enabled/dir.conf
clear
vim /www_dir/index.php
cd vim
cd /www_dir/
cd /www_dir
clear
ls -la
cd /var/www/html/
ls -la
vim index.php
cd
systemctl restart apache2
vim /etc/apache2/mods-enabled/dir.conf
clear
systemctl restart apache2
vim /etc/apache2/mods-enabled/dir.conf
clear
systemctl restart apache2
vim /etc/apache2/mods-enabled/dir.conf
clear
apache2ct1 -M | grep php
sudo
sudo a2enmod php
a2enmod php
apt update
vim /etc/apt/sources.list
apt update
apt install libapache2-mod-php php
systemctl restart apache2
apache2ct1 -M | grep php
apache2ctl -M | grep php
lsb_release -a
a2enmod php
apt update
vim /etc/apt/sources.list
clear
apt update
apt full-upgrade
clear
apt install php php8.2 libapache2-mod-php8.2
systemctl restart apache2
cd /var/www/html/
ls -la
cd
apache2ctl -M | grep php
vim /var/www/html/info.php
/var/www/html/info.php
apache2ctl -M | grep php
systemctl restart apache2
vim /var/www/html/info.php
systemctl status apache2
ls -l /var/www/html/info.php
install mariadb-server
apt instal mariadb-server
apt install mariadb-server
systemctl enable mariadb
systemctl start mariadb
mysql_secure_installation
ls -la
mysql -u root -p < /root/db-sql
mysql -u root -p < /root/db.sql
mysql -u root -p
mysql -u root -p
mysql -u root
apt install php-mysql
systemctl restart apache2
clear
vim /etc/network/interfaces
ip a
vim /etc/network/interfaces
systemctl restart networking
ip a
ping 192.168.1.1
ping -c 4 8.8.8.8
poweroff
