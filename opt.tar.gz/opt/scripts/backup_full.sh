#!/bin/bash

# backup_full.sh - Script de backup
# Uso: backup_full.sh -o <origen> -d <destino>

mostrar_ayuda() {
	echo ""
	echo "Uso: $0 -o <directorio_origen> -d <directorio_destino>"
	echo ""
	echo "Opciones:"
	echo " -o Directorio de origen a backupear (ej: /var/log)"
	echo " -d Directorio de destino donde guardar el backup (ej: /backup_dir)"
	echo " -help Muestra esta ayuda"
	echo ""
	echo "Ejemplo:"
	echo " $0 -o /var/log -d /backup_dir"
	echo ""
	exit 0
}

# Mostrar ayuda si se pasa -help
if [[ "$1" == "-help" ]]; then
	mostrar_ayuda
fi

# Procesar argumentos
while getopts "o:d:" opt; do
	case $opt in
		o) ORIGEN="$OPTARG" ;;
		d) DESTINO="$OPTARG" ;;
		*) mostrar_ayuda ;;
	esac
done

# Validar que se pasaron los argumentos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
	echo "ERROR: Debe especificar origen (-o) y destino (-d)."
	mostrar_ayuda
fi

# Validar que el origen existe y es accesible
if [[ ! -d "$ORIGEN" ]]; then
	echo "ERROR: El directorio de origen '$ORIGEN' no existe o no es accesible."
	exit 1
fi

# Validar que el destino existe y está montado
if ! mountpoint -q "$DESTINO" && [[ ! -d "$DESTINO" ]]; then
	echo "ERROR: El directorio de destino '$DESTINO' no está disponible o no está montado."
	exit 1
fi

# Generar nombre del archivo con fecha en formato AAAAMMDD
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${DESTINO}/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

# Ejecutar el backup
echo "Iniciando backup de '$ORIGEN' hacia '$ARCHIVO_BACKUP'..."
tar -czf "$ARCHIVO_BACKUP" "$ORIGEN"

if [[ $? -eq 0 ]]; then
	echo "Backup completado exitosamente: $ARCHIVO_BACKUP"
else
	echo "ERROR: El backup falló."
	exit 1
fi
